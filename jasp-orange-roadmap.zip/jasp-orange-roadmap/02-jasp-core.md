# Phase 2 — JASP Core

## Main Goal

Become comfortable performing and interpreting common statistical analyses in JASP.

---

## 2.1 JASP Interface

Learn:

- importing CSV
- importing Excel
- importing SPSS
- variable types
- labels
- filters
- computed columns

Practice with several different datasets.

---

## 2.2 Descriptive Statistics

Practice:

- frequencies
- mean
- median
- standard deviation
- variance
- quartiles
- skewness
- kurtosis

Generate:

- histograms
- boxplots
- violin plots
- Q-Q plots

---

## 2.3 One-Sample T-Test

Use when comparing a sample mean against a known or hypothesized value.

Example:

```text
Company claim: average delivery time = 30 minutes
Observed mean: 34 minutes
```

Interpret:

- t statistic
- degrees of freedom
- p-value
- confidence interval
- effect size

---

## 2.4 Independent Samples T-Test

Use for two independent groups.

Example:

```text
Desktop users vs Mobile users
```

Compare:

```text
average session duration
```

Study assumptions:

- independence
- approximate normality
- variance assumptions
- Welch's t-test

---

## 2.5 Paired Samples T-Test

Use when measurements belong to the same subjects.

Examples:

```text
Before training vs after training
Before optimization vs after optimization
```

---

## 2.6 Nonparametric Tests

Learn:

- Mann-Whitney U
- Wilcoxon signed-rank
- Kruskal-Wallis

Understand when these are useful alternatives to parametric tests.

---

## 2.7 Chi-Square Tests

Learn:

- goodness-of-fit
- test of independence

Example:

```text
Device Type vs Conversion
```

---

## 2.8 Correlation Analysis

Analyze:

- Pearson correlation
- Spearman correlation
- correlation matrices

Suggested variables:

```text
session_duration
pages_viewed
cart_items
orders
revenue
```

---

## Project — E-commerce Behavior Analysis

Suggested columns:

```text
customer_id
country
device
sessions
pages_viewed
cart_additions
orders
revenue
customer_rating
```

Perform:

1. Descriptive statistics
2. Distribution analysis
3. Correlation analysis
4. T-test
5. Mann-Whitney test
6. Chi-square test

Write a short research-style summary.
