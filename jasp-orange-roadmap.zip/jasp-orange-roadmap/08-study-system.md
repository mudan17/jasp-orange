# Study System

## Recommended Daily Pattern

Use:

```text
Theory
  ↓
Tool Practice
  ↓
Dataset Exercise
  ↓
Interpretation
  ↓
Python Reproduction
```

Suggested daily allocation:

| Activity | Time |
|---|---:|
| Theory | 60 min |
| JASP / Orange | 90 min |
| Dataset exercise | 60 min |
| Python reproduction | 60 min |
| Review and notes | 30 min |

Total: approximately 4–5 hours.

If you have more time, prioritize projects and datasets instead of consuming more courses.

---

# Five Questions for Every Technique

## 1. What problem does it solve?

Example:

```text
Independent t-test:
Compare the means of two independent groups.
```

## 2. What assumptions does it make?

Examples:

```text
independence
normality
variance assumptions
```

## 3. What output does it produce?

Examples:

```text
test statistic
p-value
confidence interval
effect size
```

## 4. How do I interpret it?

Write the result in ordinary language.

## 5. How can I reproduce it in Python?

This connects statistical knowledge with engineering.

---

# Recommended Learning Loop

Use the same dataset across tools.

```text
E-commerce Dataset
       │
       ├── JASP
       │    ├── Descriptive statistics
       │    ├── T-tests
       │    ├── ANOVA
       │    └── Regression
       │
       ├── Orange
       │    ├── Classification
       │    ├── Feature selection
       │    ├── Clustering
       │    └── Model evaluation
       │
       └── Python
            ├── Pandas
            ├── Statsmodels
            ├── Scikit-learn
            └── Production API
```

---

# Final Skill Target

You should eventually be comfortable with:

```text
Business Question
       ↓
Data Collection
       ↓
Data Cleaning
       ↓
Exploratory Analysis
       ↓
Statistical Analysis
       ↓
Machine Learning
       ↓
Model Evaluation
       ↓
Interpretation
       ↓
Production Deployment
```

## Tool Roles

| Tool | Main Purpose |
|---|---|
| JASP | Statistical analysis |
| Orange | Visual machine learning |
| Python | Automation and production |
| Pandas | Data preparation |
| Statsmodels | Statistical programming |
| Scikit-learn | Machine learning |
| SQL | Data retrieval |
| PostgreSQL | Persistent data |
| FastAPI | Model/API serving |
| Docker | Deployment |

Target profile:

> Software Engineer + Data Analyst + Statistical Practitioner + ML Engineer
