# Phase 7 — Portfolio Projects

## Goal

Build projects that demonstrate statistics, machine learning, interpretation, and engineering.

---

## Project 1 — Website A/B Testing

Tools:

```text
JASP
Python
```

Suggested columns:

```text
visitor
variant
converted
session_duration
pages_viewed
revenue
```

Questions:

- Did variant B improve conversion?
- Is the difference statistically significant?
- What is the effect size?
- What is the confidence interval?
- Does the result matter commercially?

---

## Project 2 — Customer Churn

Tools:

```text
Orange
Scikit-learn
FastAPI
```

Models:

- logistic regression
- random forest
- gradient boosting
- SVM

Evaluate:

- accuracy
- precision
- recall
- F1
- ROC-AUC

---

## Project 3 — Survey Research

Tools:

```text
JASP
Python
```

Study:

- descriptive statistics
- reliability
- factor analysis
- correlation
- ANOVA
- regression
- Bayesian analysis

---

## Project 4 — Customer Segmentation

Tools:

```text
Orange
Python
```

Pipeline:

```text
Data
 ↓
Cleaning
 ↓
Scaling
 ↓
PCA
 ↓
Clustering
 ↓
Visualization
 ↓
Business Interpretation
```

---

## Project 5 — End-to-End Data Science Platform

Suggested architecture:

```text
React / Next.js
      │
      ↓
   FastAPI
      │
 ┌────┼──────────┐
 ↓    ↓          ↓
Postgres ML     Files
         ↓        ↓
       MLflow     S3
         ↓
     Predictions
```

Possible features:

- upload dataset
- inspect schema
- missing-value analysis
- descriptive statistics
- automated charts
- statistical testing
- model training
- model comparison
- predictions
- experiment tracking

This can become the strongest project in your portfolio.
