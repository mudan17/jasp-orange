# Phase 5 — Advanced Orange

## Main Goal

Go beyond basic classification into clustering, PCA, leakage, imbalance, and model comparison.

---

## 5.1 Clustering

Study:

- K-Means
- hierarchical clustering
- unsupervised learning concepts

---

## 5.2 K-Means

Suggested features:

```text
annual_spending
purchase_frequency
average_order_value
site_visits
```

Interpret clusters as meaningful business segments.

---

## 5.3 Hierarchical Clustering

Learn:

- dendrogram
- linkage methods
- distance measures

Compare results with K-Means.

---

## 5.4 PCA

Understand:

```text
Many Features
    ↓
PCA
    ↓
Fewer Components
```

Use PCA for:

- dimensionality reduction
- visualization
- correlated-feature reduction
- noise reduction

---

## 5.5 Data Leakage

Example of leakage:

```text
Predicting churn using account_closed_date
```

Learn how features can accidentally reveal future information.

---

## 5.6 Class Imbalance

Example:

```text
Fraud = 1%
Not Fraud = 99%
```

A model that always predicts `Not Fraud` has 99% accuracy but is useless.

Focus on:

- precision
- recall
- F1
- PR-AUC
- confusion matrix

---

## 5.7 Model Comparison

Compare:

```text
Logistic Regression
Random Forest
SVM
Gradient Boosting
Neural Network
```

Choose the best model according to the business objective.

---

## Project — Customer Segmentation

Workflow:

```text
Customer Dataset
      ↓
Imputation
      ↓
Normalization
      ↓
PCA
      ↓
K-Means
      ↓
Cluster Visualization
```

For each cluster, describe:

- demographic profile
- purchase patterns
- customer value
- recommended strategy
