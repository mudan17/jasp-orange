# Phase 4 — Orange Core

## Main Goal

Learn practical machine learning visually before reproducing it in Python.

---

## 4.1 Orange Interface

Learn:

- canvas
- widgets
- connections
- workflows
- signals between widgets

Basic workflow:

```text
File
 ↓
Data Table
 ↓
Distributions
```

---

## 4.2 Data Exploration

Use:

- Data Table
- Distributions
- Box Plot
- Scatter Plot
- Correlations
- Heat Map

Ask:

- which variables are related?
- where are the outliers?
- are classes imbalanced?
- which groups behave differently?

---

## 4.3 Select Columns

Define:

```text
Features
Target
Metadata
Ignored columns
```

Example:

```text
Features:
age
income
sessions
orders

Target:
churn

Meta:
customer_id
```

---

## 4.4 Missing Data

Study:

- removing rows
- mean imputation
- median imputation
- most-frequent category
- model-based imputation

---

## 4.5 Normalization

Learn:

- standardization
- min-max normalization

Understand why feature scale matters for some algorithms.

---

## 4.6 Feature Selection

Study:

- information gain
- correlation
- chi-square ranking
- feature importance

Remember:

```text
More features ≠ better model
```

---

## 4.7 Classification Models

Learn:

- logistic regression
- decision tree
- random forest
- k-nearest neighbors
- SVM
- neural network
- gradient boosting

Focus first on model behavior rather than parameter tuning.

---

## 4.8 Test & Score

Understand:

- training vs testing
- cross-validation
- random sampling

Metrics:

```text
Accuracy
Precision
Recall
F1
AUC
Log Loss
```

---

## 4.9 Confusion Matrix

Understand:

```text
True Positive
True Negative
False Positive
False Negative
```

Consider the business cost of each error type.

---

## 4.10 ROC Analysis

Learn:

- ROC curve
- sensitivity
- specificity
- decision thresholds
- AUC

---

## Project — Customer Churn Prediction

Workflow:

```text
File
 ↓
Select Columns
 ↓
Impute
 ↓
Normalize
 ↓
Rank
 ↓
Logistic Regression
Random Forest
Gradient Boosting
SVM
 ↓
Test & Score
 ↓
ROC Analysis
 ↓
Confusion Matrix
```

Record:

- best model
- best AUC
- best recall
- best F1
- business interpretation
