# Phase 1 — Statistics Foundations

## Main Goal

Build the statistical intuition needed for JASP, Orange, and practical data science.

You should eventually be able to look at a dataset and decide:

- what kind of variables it contains
- what questions can be answered
- which statistical method is appropriate
- what assumptions need to hold
- how to interpret results correctly

---

## 1.1 Types of Data

Learn:

- numerical data
- categorical data
- nominal variables
- ordinal variables
- interval variables
- ratio variables
- discrete variables
- continuous variables
- dependent variables
- independent variables

### Exercise

Take a dataset and classify every column by type.

---

## 1.2 Descriptive Statistics

Learn:

- mean
- median
- mode
- minimum
- maximum
- range
- variance
- standard deviation
- quartiles
- percentiles
- interquartile range

### Exercise

Use:

```text
10, 12, 12, 13, 15, 18, 20, 100
```

Calculate the major descriptive statistics, then remove `100` and compare the result.

---

## 1.3 Data Distributions

Study:

- normal distribution
- skewed distributions
- uniform distribution
- binomial distribution
- Poisson distribution
- positive and negative skew
- kurtosis
- outliers

Learn these plots:

- histogram
- box plot
- density plot
- Q-Q plot

---

## 1.4 Probability

Study:

- probability
- conditional probability
- independent events
- dependent events
- expected value

Understand:

```text
P(A)
P(B)
P(A ∩ B)
P(A | B)
```

Focus on intuition before advanced mathematics.

---

## 1.5 Sampling

Learn:

- population
- sample
- random sampling
- convenience sampling
- sampling bias
- representativeness
- sample size

Concept:

```text
Population
   ↓
Sample
   ↓
Statistic
   ↓
Inference about Population
```

---

## 1.6 Confidence Intervals

Understand:

- point estimates
- confidence intervals
- margin of error
- 90%, 95%, and 99% intervals

Example:

```text
Mean conversion = 6.3%
95% CI = [5.8%, 6.8%]
```

---

## 1.7 Hypothesis Testing

Learn:

```text
H0 = Null hypothesis
H1 = Alternative hypothesis
```

Example:

```text
H0: The new landing page does not improve conversion.
H1: The new landing page improves conversion.
```

Study:

- significance level
- p-value
- Type I error
- Type II error
- rejecting vs failing to reject H0

---

## 1.8 P-values

Understand what a p-value means and what it does not mean.

Incorrect interpretation:

```text
p = 0.02 means the hypothesis is 98% likely to be true.
```

Instead, interpret it relative to the null hypothesis and observed data.

---

## 1.9 Effect Size

Learn:

- Cohen's d
- Pearson's r
- eta squared
- odds ratio

Important:

```text
Statistical significance ≠ practical importance
```

---

## 1.10 Correlation

Learn:

- Pearson correlation
- Spearman correlation
- positive correlation
- negative correlation
- weak and strong correlation

Remember:

```text
Correlation ≠ causation
```

---

## Mini Project — Web Analytics Dataset

Suggested columns:

```text
visitor_id
country
device
session_duration
pages_viewed
conversion
revenue
```

Perform:

- descriptive statistics
- distributions
- correlation analysis
- outlier analysis
- group comparisons

---

## Completion Checklist

You should be comfortable explaining:

- mean vs median
- variance
- standard deviation
- normal distribution
- sampling
- confidence intervals
- null and alternative hypotheses
- p-values
- statistical significance
- practical significance
- correlation
