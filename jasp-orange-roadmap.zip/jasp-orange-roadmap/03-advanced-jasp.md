# Phase 3 — Advanced JASP

## Main Goal

Learn regression, ANOVA, reliability, factor analysis, and Bayesian analysis.

---

## 3.1 Simple Linear Regression

Model:

```text
Y = β0 + β1X + ε
```

Example:

```text
Revenue = f(Advertising Spend)
```

Study:

- intercept
- coefficient
- R²
- residuals
- confidence intervals

---

## 3.2 Multiple Regression

Example predictors:

```text
advertising_spend
sessions
discount
customer_age
```

Study:

- multiple predictors
- adjusted R²
- coefficient interpretation
- interaction effects

---

## 3.3 Regression Diagnostics

Study:

- residual plots
- heteroscedasticity
- multicollinearity
- VIF
- influential observations
- Cook's distance

---

## 3.4 Logistic Regression

Use for categorical targets.

Example:

```text
customer_churn = yes/no
```

Features:

```text
monthly_spend
support_tickets
login_frequency
subscription_age
```

Understand:

- odds
- odds ratios
- probabilities
- coefficient interpretation

---

## 3.5 ANOVA

Learn:

- one-way ANOVA
- two-way ANOVA
- post-hoc testing

Example:

```text
Basic
Professional
Enterprise
```

Compare mean revenue or satisfaction across groups.

---

## 3.6 Repeated Measures ANOVA

Example:

```text
Week 1
Week 4
Week 8
```

for the same participants.

---

## 3.7 ANCOVA

Learn to compare groups while controlling for continuous covariates.

---

## 3.8 Reliability Analysis

Learn:

- Cronbach's alpha
- item-total correlations
- internal consistency

Useful for survey scales.

---

## 3.9 Factor Analysis

Learn:

- latent variables
- factor loadings
- exploratory factor analysis

Example latent dimensions:

```text
Satisfaction
Trust
Usability
Price Sensitivity
```

---

## 3.10 Bayesian Statistics

Learn:

- prior
- likelihood
- posterior
- Bayesian updating
- Bayes factor
- credible interval

Concept:

```text
Prior belief
   +
Observed data
   ↓
Posterior belief
```

---

## 3.11 Bayesian T-Test

Compare frequentist and Bayesian results.

Example:

```text
Frequentist:
p = 0.03

Bayesian:
BF10 = 5.4
```

---

## 3.12 Bayesian Regression

Study:

- priors
- posterior estimates
- credible intervals
- model comparison

---

## Project — Customer Satisfaction Research

Suggested columns:

```text
age
gender
subscription_type
usage_frequency
support_experience
ease_of_use
reliability
pricing_satisfaction
overall_satisfaction
churn
```

Perform:

- descriptive statistics
- reliability analysis
- factor analysis
- ANOVA
- multiple regression
- logistic regression
- Bayesian comparison

Write:

```text
Research Question
Method
Results
Interpretation
Limitations
Conclusion
```
