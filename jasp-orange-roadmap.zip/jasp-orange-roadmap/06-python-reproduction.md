# Phase 6 — Reproduce Everything in Python

## Main Goal

Convert JASP and Orange knowledge into reproducible and production-ready Python workflows.

---

## 6.1 JASP to Python

Recommended tools:

```text
pandas
numpy
scipy
statsmodels
pingouin
matplotlib
```

Reproduce:

- t-tests
- ANOVA
- correlation
- regression
- logistic regression
- confidence intervals

Example:

```python
from scipy.stats import ttest_ind

group_a = df[df["group"] == "A"]["revenue"]
group_b = df[df["group"] == "B"]["revenue"]

result = ttest_ind(group_a, group_b)

print(result)
```

Compare with JASP output.

---

## 6.2 Regression with Statsmodels

```python
import statsmodels.api as sm

X = df[["sessions", "orders", "discount"]]
X = sm.add_constant(X)

y = df["revenue"]

model = sm.OLS(y, X).fit()

print(model.summary())
```

Compare:

- coefficients
- p-values
- confidence intervals
- R²

---

## 6.3 Orange to Scikit-learn

Learn:

```text
train_test_split
Pipeline
StandardScaler
SimpleImputer
cross_val_score
GridSearchCV
```

---

## 6.4 Classification Pipeline

```python
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

pipeline = Pipeline([
    ("imputer", SimpleImputer()),
    ("scaler", StandardScaler()),
    ("model", LogisticRegression())
])
```

Conceptually this matches:

```text
File
 ↓
Impute
 ↓
Normalize
 ↓
Logistic Regression
```

---

## 6.5 Model Evaluation

Use:

```python
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)
```

Compare Python results to Orange's Test & Score.

---

## 6.6 Cross Validation

Understand:

```text
Dataset
 ↓
Fold 1
Fold 2
Fold 3
Fold 4
Fold 5
 ↓
Average Performance
```

Learn:

```python
cross_val_score()
```

---

## 6.7 Feature Engineering

Examples:

From:

```text
signup_date
last_login_date
```

derive:

```text
account_age_days
days_since_last_login
```

From:

```text
orders
revenue
```

derive:

```text
average_order_value
```

---

## Project — Complete ML Pipeline

Build:

```text
Raw CSV
  ↓
Pandas
  ↓
Data Cleaning
  ↓
Feature Engineering
  ↓
Train/Test Split
  ↓
Preprocessing
  ↓
Model Training
  ↓
Cross Validation
  ↓
Evaluation
  ↓
Prediction API
```

Suggested stack:

```text
Python
Pandas
Scikit-learn
FastAPI
PostgreSQL
Docker
```
